#ifndef __RCC_CONFIGURATION_H
#define __RCC_CONFIGURATION_H

#include"stm32f10x_lib.h"

void RCC_Configuration(void);

#endif


