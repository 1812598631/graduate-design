#ifndef __USART_CONFIGURATION_H
#define __USART_CONFIGURATION_H
#include"stm32f10x_lib.h"

void USART_Configuration(void);

#endif


