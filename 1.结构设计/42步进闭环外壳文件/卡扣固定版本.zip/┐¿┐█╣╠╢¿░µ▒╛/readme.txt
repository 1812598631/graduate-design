版本区分：
SWITCH：拨码开关版本
EXTERNAL_OLED：外接OLED屏幕版本
INNER_OLED：内置OLED屏幕版本
带NONSILK：外壳表面不带字符丝印

打印建议：
表面带字符丝印的文件建议打树脂和尼龙，字符细节才能表现出来

